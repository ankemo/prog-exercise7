fun_AddFour <- function(x){
  
  x <- x + 4
  
}